-- Additive migration: does not rebuild or delete existing UNITED KERALAM data.
CREATE TABLE IF NOT EXISTS venues(
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  location TEXT DEFAULT '',
  home_team_id INT REFERENCES teams(id) ON DELETE SET NULL,
  capacity INT NOT NULL DEFAULT 0,
  established_year INT
);
